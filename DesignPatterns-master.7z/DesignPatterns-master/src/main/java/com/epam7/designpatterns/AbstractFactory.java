package com.epam7.designpatterns;

public abstract class AbstractFactory {
	   abstract Shape getShape(String shapeType) ;
	}