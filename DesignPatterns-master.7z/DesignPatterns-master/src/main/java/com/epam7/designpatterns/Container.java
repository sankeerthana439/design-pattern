package com.epam7.designpatterns;

public interface Container {
	   public Iterator getIterator();
	}