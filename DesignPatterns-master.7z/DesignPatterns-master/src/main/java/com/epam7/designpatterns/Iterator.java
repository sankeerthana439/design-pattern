package com.epam7.designpatterns;

public interface Iterator {
	   public boolean hasNext();
	   public Object next();
	}
